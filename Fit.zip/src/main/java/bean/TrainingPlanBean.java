package bean;

import model.TrainingPlan;

import java.time.LocalDate;
import java.util.List;

public class TrainingPlanBean {
    private int requestId;
    private String notes;
    private LocalDate expiration;
    private List<ExerciseBean> exercises;

    public TrainingPlanBean(int requestId,String notes,LocalDate expiration,List<ExerciseBean> exercises){
        this.requestId=requestId;
        this.notes=notes;
        this.expiration=expiration;
        this.exercises=exercises;
    }

    public int getRequestId(){
        return this.requestId;
    }

    public String getNotes(){
        return this.notes;
    }
    public LocalDate getExpiration(){
        return this.expiration;
    }

    public List<ExerciseBean> getExercises(){
        return this.exercises;
    }


}
