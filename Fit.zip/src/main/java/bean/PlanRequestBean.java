package bean;

import model.FitnessGoal;
import model.RequestStatus;

public class PlanRequestBean {
    String email;
    String ptEmail;
    FitnessGoal goal;
    RequestStatus status;

    public PlanRequestBean(String athlete,String ptEmail,FitnessGoal goal){
        this.email=athlete;
        this.ptEmail=ptEmail;
        this.goal=goal;
        this.status=RequestStatus.PENDING;
    }

    public FitnessGoal getGoal() {
        return goal;
    }

    public String getAthleteEmail() {
        return email;
    }

    public String getPtEmail() {
        return ptEmail;
    }
}
