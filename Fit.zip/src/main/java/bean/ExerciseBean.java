package bean;

import java.util.List;

public class ExerciseBean {
    private String name;
    private int sets;
    private int reps;
    private List<String> techniques;

    public  ExerciseBean(String name,int sets,int reps,List<String> techniques){
        this.name=name;
        this.sets=sets;
        this.reps=reps;
        this.techniques=techniques;
    }

    public String getExerciseName(){
        return this.name;
    }

    public int getSets(){
        return this.sets;
    }

    public int getReps(){
        return this.reps;
    }

    public List<String> getTechniques(){
        return this.techniques;
    }

}
