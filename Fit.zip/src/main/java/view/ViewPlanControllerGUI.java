package view;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class ViewPlanControllerGUI {
    Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }


    public void backToDashboard(ActionEvent e) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("/AthleteDashboard.fxml"));
        VBox root=loader.load();
        AthleteDashboardGraphicControllerGUI controllerGUI=loader.getController();
        controllerGUI.setStage(stage);
        Scene s=new Scene(root);
        stage.setScene(s);
        stage.show();



    }


}
