package view;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Athlete;
import model.Gender;

import java.io.IOException;

public class AthleteDashboardGraphicControllerGUI {
    @FXML
    Label nomeAtleta = new Label("trone");
    @FXML
    Button logoutButton;
    @FXML
    Button requestButton;
    @FXML
    Button viewPlanButton;
    Stage mystage;

    public AthleteDashboardGraphicControllerGUI() {
    }
    
    public void setStage(Stage stage) {
        this.mystage = stage;
    }

    public void setNomeAtleta(String nomeAtleta) {
        this.nomeAtleta.setText("Benvenuto " + nomeAtleta);
    }

    public void requestPlan(ActionEvent e) throws IOException {
        System.out.println("DEBUG: requestPlan() called");
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/RequestPlan.fxml"));
            System.out.println("DEBUG: FXMLLoader created");

            VBox root = loader.load();
            System.out.println("DEBUG: FXML loaded");

            RequestPlanGraphicGraphicControllerGUI planController = loader.getController();
            System.out.println("DEBUG: Controller retrieved: " + planController);

            // Crea un atleta di test per il prototipo
            // In produzione, questo dovrebbe venire dal sistema di login
            Athlete testAthlete = new Athlete(
                    "francesco@test.com",
                    "Francesco",
                    "Rossi",
                    75.5,
                    180,
                    Gender.MALE
            );
            System.out.println("DEBUG: Test athlete created");

            // Passa l'atleta e lo stage al controller della richiesta
            planController.setAthlete(testAthlete);
            planController.setStage(mystage);
            System.out.println("DEBUG: Athlete and stage set");

            Scene s = new Scene(root);
            mystage.setScene(s);
            mystage.show();
            System.out.println("DEBUG: Scene displayed");
        } catch (Exception ex) {
            System.out.println("ERROR in requestPlan: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    public void viewPlan(ActionEvent e) throws IOException {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("/ViewPlan.fxml"));
        javafx.scene.layout.AnchorPane root=loader.load();
        ViewPlanControllerGUI planControllerGUI=loader.getController();
        planControllerGUI.setStage(mystage);

        Scene j=new Scene(root);
        mystage.setScene(j);
        mystage.show();

    }
    public void logout(ActionEvent e){
        System.exit(0);
    }





}
