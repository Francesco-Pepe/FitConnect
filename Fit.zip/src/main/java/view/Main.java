package view;

import bean.PersonalTrainerBean;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.FitnessGoal;

import java.io.IOException;
import java.util.List;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        // Carica il file FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/AthleteDashboard.fxml"));
        VBox root = loader.load();
         AthleteDashboardGraphicControllerGUI controller = loader.getController();

        // Passa lo stage al controller (IMPORTANTE!)
        controller.setStage(stage);

        // Crea la scene e configura lo stage
        Scene scene = new Scene(root);
        stage.setTitle("FitConnect");
        stage.setScene(scene);
        stage.show();
        controller.setNomeAtleta("Francesco");

    }

    public static void main(String[] args) {
        launch(args);
    }
}
