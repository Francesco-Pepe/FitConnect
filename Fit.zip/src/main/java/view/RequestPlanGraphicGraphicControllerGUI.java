package view;
import bean.PlanRequestBean;
import controller.ManageCustomPlanController;
import controller.RequestPlanGraphicController;
import eng.DAOFactory;
import exception.DAOException;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Athlete;
import model.FitnessGoal;
import model.PersonalTrainer;


import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Controller GUI per la richiesta di piano customizzato
 * Estende RequestPlanController per riutilizzare la logica comune
 */
public class RequestPlanGraphicGraphicControllerGUI extends RequestPlanGraphicController
        implements Initializable {

    @FXML
    private ComboBox<PersonalTrainer> trainerComboBox;

    @FXML
    private ToggleGroup fitnessGoalGroup;

    @FXML
    private TextArea notesArea;

    @FXML
    private Button sendRequestBtn;

    @FXML
    private Button cancelBtn;

    private Stage stage;
    private Athlete athlete;

    /**
     * Costruttore vuoto richiesto da FXML
     */
    public RequestPlanGraphicGraphicControllerGUI() {
        super(null);
    }

    /**
     * Setter per impostare l'atleta e il controller astratto
     */
    public void setAthlete(Athlete athlete) {
        this.athlete = athlete;
        this.currentAthlete = athlete;
    }

    /**
     * Setter per il stage
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadPersonalTrainers();
        } catch (Exception e) {
            showAlert("Errore", "Errore nel caricamento dei trainer", e.getMessage());
        }
    }

    /**
     * Carica la lista dei personal trainer nel ComboBox
     */
    private void loadPersonalTrainers() {
        try {
            List<PersonalTrainer> trainers =
                DAOFactory.getInstance().getPersonalTrainerDAO().fetchAll();

            trainerComboBox.setItems(
                FXCollections.observableArrayList(trainers)
            );

            // Custom cell factory per mostrare nome, cognome e email
            trainerComboBox.setCellFactory(param ->
                new ListCell<PersonalTrainer>() {
                    @Override
                    protected void updateItem(PersonalTrainer item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty || item == null) {
                            setText(null);
                        } else {
                            setText(item.getName() + " " + item.getSurname() +
                                   " (" + item.getEmail() + ")");
                        }
                    }
                }
            );

        } catch (Exception e) {
            throw new DAOException("Errore caricamento personal trainer", e);
        }
    }

    /**
     * Handler del pulsante "Send Request"
     */
    @FXML
    private void handleSendRequest(ActionEvent event) {
        try {
            PersonalTrainer selectedTrainer =
                trainerComboBox.getSelectionModel().getSelectedItem();

            // Ottieni il FitnessGoal dal RadioButton selezionato
            Toggle selectedToggle = fitnessGoalGroup.getSelectedToggle();
            if (selectedToggle == null) {
                showAlert("Attenzione", "Errore",
                    "Seleziona un obiettivo fitness");
                return;
            }

            RadioButton selectedRadio = (RadioButton) selectedToggle;
            String goalText = selectedRadio.getText();
            FitnessGoal selectedGoal = mapTextToFitnessGoal(goalText);

            if (selectedTrainer == null || selectedGoal == null) {
                showAlert("Attenzione", "Errore",
                    "Seleziona sia un trainer che un obiettivo");
                return;
            }

            // Crea il bean (nota: usa email come stringhe)
            PlanRequestBean requestBean = new PlanRequestBean(
                athlete.getEmail(),
                selectedTrainer.getEmail(),
                selectedGoal
            );

            // Invia al controller applicativo
            ManageCustomPlanController appController =
                new ManageCustomPlanController();
            appController.sendPlanRequest(requestBean);

            // Mostra successo
            showAlert("Successo", "Richiesta inviata",
                "La tua richiesta è stata inviata a " +
                selectedTrainer.getName() + "!");

            // Ritorna al dashboard
            returnToDashboard();

        } catch (Exception e) {
            showAlert("Errore", "Errore nell'invio",
                e.getMessage());
        }
    }

    /**
     * Handler del pulsante "Cancel"
     */
    @FXML
    private void handleCancel(ActionEvent event) {
        returnToDashboard();
    }

    /**
     * Ritorna alla dashboard dell'atleta
     */
    @FXML
    private void returnToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AthleteDashboard.fxml"));
            VBox root = loader.load();
            AthleteDashboardGraphicControllerGUI dashboardController = loader.getController();
            dashboardController.setStage(stage);
            dashboardController.setNomeAtleta(athlete.getName());

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            showAlert("Errore", "Errore nel ritorno",
                "Non è stato possibile tornare alla dashboard: " + e.getMessage());
        }
    }

    /**
     * Mappa il testo del RadioButton al FitnessGoal enum
     */
    private FitnessGoal mapTextToFitnessGoal(String text) {
        return switch(text) {
            case "Weight Loss" -> FitnessGoal.WEIGHT_LOSS;
            case "Improve Strenght" -> FitnessGoal.STRENGHT;
            case "Body Recomposition" ->FitnessGoal.BODY_RECOMPOSITION;
            default -> null;
        };
    }

    /**
     * Helper per mostrare alert
     */
    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    // ===== Implementazione metodi astratti (non usati nella GUI) =====

    @Override
    protected void showFitnessGoalOptions() {
        // Già mostrate nell'FXML
    }

    @Override
    protected void showPersonalTrainerList(List<PersonalTrainer> trainers) {
        // Già caricati nell'initialize()
    }

    @Override
    protected void onSuccess(String message) {
        showAlert("Successo", "Operazione riuscita", message);
    }

    @Override
    protected void onError(String message) {
        showAlert("Errore", "Errore", message);
    }

    @Override
    protected void onCancellation() {
        returnToDashboard();
    }
}
