package controller;

import bean.PlanRequestBean;
import eng.DAOFactory;
import exception.DAOException;
import model.Athlete;
import model.FitnessGoal;
import model.PersonalTrainer;

import java.util.List;

/**
 * Controller astratto per il flusso di richiesta di piano custom.
 * Contiene la logica comune sia per GUI che per CLI.
 */
public abstract class RequestPlanGraphicController {

    protected Athlete currentAthlete;

    public RequestPlanGraphicController(Athlete athlete) {
        this.currentAthlete = athlete;
    }

    /**
     * Avvia il flusso di richiesta del piano (template method pattern)
     */
    public final void startPlanRequestFlow() {
        try {
            // 1. Mostra le opzioni di FitnessGoal
            showFitnessGoalOptions();

            // 2. Carica i PT disponibili
            List<PersonalTrainer> availableTrainers = loadAvailableTrainers();
            showPersonalTrainerList(availableTrainers);

        } catch (Exception e) {
            onError("Errore nel caricamento: " + e.getMessage());
        }
    }

    /**
     * Carica i personal trainer disponibili dal DAO
     */
    protected List<PersonalTrainer> loadAvailableTrainers() {
        try {
            return DAOFactory.getInstance().getPersonalTrainerDAO().fetchAll();
        } catch (Exception e) {
            throw new DAOException("Errore caricamento PT", e);
        }
    }

    /**
     * Crea il PlanRequestBean e lo invia al controller applicativo
     */
    protected void submitRequest(PersonalTrainer selectedTrainer,
                                FitnessGoal selectedGoal) {
        try {
            // Valida la selezione
            if (selectedTrainer == null || selectedGoal == null) {
                onError("Seleziona un PT e un obiettivo fitness");
                return;
            }

            // Crea il bean (note: usa email come stringhe)
            PlanRequestBean requestBean = new PlanRequestBean(
                currentAthlete.getEmail(),
                selectedTrainer.getEmail(),
                selectedGoal
            );

            // Invia al controller applicativo
            ManageCustomPlanController appController =
                new ManageCustomPlanController();
            appController.sendPlanRequest(requestBean);

            onSuccess("Richiesta inviata con successo!");

        } catch (Exception e) {
            onError("Errore nell'invio della richiesta: " + e.getMessage());
        }
    }

    // ===== METODI ASTRATTI - da implementare nei sottoclassi =====

    /**
     * Mostra le opzioni di FitnessGoal disponibili
     */
    protected abstract void showFitnessGoalOptions();

    /**
     * Mostra la lista di personal trainer disponibili
     */
    protected abstract void showPersonalTrainerList(
        List<PersonalTrainer> trainers);

    /**
     * Notifica di successo dell'operazione
     */
    protected abstract void onSuccess(String message);

    /**
     * Notifica di errore
     */
    protected abstract void onError(String message);

    /**
     * Gestisce l'annullamento dell'operazione
     */
    protected abstract void onCancellation();
}



